// import { useState } from 'react'    
// function Display2(){
//     const [Name,setName]=useState("")
//     console.log("Current Name is :", {Name})
//     return (
//         <>
//         <h1>Display2 Component</h1>
//         <h1>{Name}</h1>
//         <input type="text" value={Name} onChange={(e)=>{setName(e.target.value)}}></input>
//         <button onClick={()=>{setName("")}}>Clear</button>
//         </>
//     )
// }
// export default Display2

import { useState } from 'react' 
import { useRef } from 'react'   
function Display2(){
    const [Name,setName]=useState("")
    const input = useRef()
    const view=()=>{
        console.log("Current Name is :",input.current.value)
        setName(input.current.value)
    }
    return (
        <>
        <h1>Display2 Component</h1>
        <h1>{Name}</h1>
        <input type="text" ref={input}></input>
        <button onClick={view}>Click</button>
        </>
    )
}
export default Display2