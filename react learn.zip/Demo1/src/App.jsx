// import { useState } from "react"
// import Display from "./Display"

// function App() {
//   const [Data,setData]=useState()
//   var value="Hello from App Component"
//   var name="Moneshwar R"
//   var age=24
//   const arr=[1,2,3,4,5]
//   const person={name:"Ravi",age:20}
//   const receive=(val)=>{
//     setData(val)
//   }
//   return (
//     <>
//     <h1>Welcome</h1>
//     <h2>Data from Child:{Data}</h2>
//     <h1>---------------------------------------------</h1>
//     <Display n={name} a={age} arr={arr} person={person} receive={receive} value={value}/>
//     </>
//   )
// }

// export default App

import React from "react"
import { createContext, useContext } from "react"
import { useState } from "react"
import Display from "./Display"
export const AppContext=createContext()
function App() {
  const [Data,setData]=useState()
  var value="Hello from App Component"
  var name="Moneshwar R"
  var age=24
  const arr=[1,2,3,4,5]
  const person={name:"Ravi",age:20}
  const receive=(val)=>{
    setData(val)
  }
  return (
    <AppContext.Provider value={{name,age,arr,person,receive,value}}>
    <h1>Welcome</h1>
    <h2>Data from Child:{Data}</h2>
    <h1>---------------------------------------------</h1>
    {/* <Display n={name} a={age} arr={arr} person={person} receive={receive} value={value}/> */}
    <Display/>
    </AppContext.Provider>
  )
}

export default App
