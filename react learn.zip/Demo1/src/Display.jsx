// import Display1 from "./Display1"
// function Display(datas){
//     const x="i am child component"
//     const {n,a,arr,person,receive,value}=datas
//     return (
//         <>                      {/* Fragment Syntax */}
//         <h2>Hello {n} {a}</h2>
//         <h2>Array Elements</h2>
//         <ul>
//         {
//             arr.map((val,ind)=>{
//                 return <li key={ind}>{val}</li>
//             })
//         }
//         </ul>
//         <h2>{person.name} {person.age}</h2>
//         <h2>Software Developer</h2>
//         <button onClick={()=>{receive(x)}}>Send Data to Parent</button>
//         <h1>---------------------------------------------</h1>
//         <Display1 value={value}/>
//         </>
//     )
// }
// export default Display


import { use } from "react"
import { createContext, useContext } from "react"
import Display1 from "./Display1"
import { AppContext } from "./App"
function Display(){
    const {name,age,arr,person,receive,value}=useContext(AppContext)
    const x="i am child component"
    // const {n,a,arr,person,receive,value}=datas
    return (
        <>                      {/* Fragment Syntax */}
        <h2>Hello {name} {age}</h2>
        <h2>Array Elements</h2>
        <ul>
        {
            arr.map((val,ind)=>{
                return <li key={ind}>{val}</li>
            })
        }
        </ul>
        <h2>{person.name} {person.age}</h2>
        <h2>Software Developer</h2>
        <button onClick={()=>{receive(x)}}>Send Data to Parent</button>
        <h1>---------------------------------------------</h1>
        {/* <Display1 value={value}/> */}
        <Display1/>
        </>
    )
}
export default Display