import { useState } from "react";
import { useEffect } from "react";
const Display3=()=>{
    const [Data,setData]=useState(100)
    useEffect(()=>{
        console.log("Data changed:",{Data})
    })
    return(
        <>
        <h1>This is Display3 Component</h1>
        <h1>The Data is : {Data}</h1>
        <button onClick={()=>{
            setData((x)=>x=x+1)
        }}>Increment</button>
        </>
    )
}
export default Display3