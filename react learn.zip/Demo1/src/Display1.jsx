// function Display1(){
//     var name="Hello"
//     console.log("Outside Function", {name})
//     function changeName(s){
//         var name=s
//         console.log("Inside Function", {name})
//     }
//     return (
//         <>
//         <h1>This is Display Component</h1>
//         <h1>Name is : {name}</h1>
//         <button onClick={()=>{changeName("World")}}> Click Here!!!</button>
//         </>
//     )
// }
// export default Display1

////////////////////// Using useState Hook //////////////////////
// import { useState } from "react"
// function Display1(props){
//     const {value}=props
//     const [Name,setName]=useState("Hello")
//     console.log("Outside Function", {Name})
//     return (
//         <>
//         <h1>This is Display1 Component</h1>
//         <h1>Name is : {Name}</h1>
//         <button onClick={()=>{setName("World")}}> Click Here!!!</button>
//         <h2>Got Data from App:{value}</h2>
//         </>
//     )
// }
// export default Display1



import { useState } from "react"
import { createContext, useContext } from "react"
import { AppContext } from "./App"
function Display1(){
    const {value}=useContext(AppContext)
    // const {value}=props
    const [Name,setName]=useState("Hello")
    console.log("Outside Function", {Name})
    return (
        <>
        <h1>This is Display1 Component</h1>
        <h1>Name is : {Name}</h1>
        <button onClick={()=>{setName("World")}}> Click Here!!!</button>
        <h2>Got Data from App:{value}</h2>
        </>
    )
}
export default Display1