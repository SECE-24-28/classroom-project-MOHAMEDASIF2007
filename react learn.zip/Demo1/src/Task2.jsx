import { useState } from "react";
function Task2(){
    const [Arr,setArr]=useState([1,2,3,4,5])
    const [Num,setNum]=useState(10)
    function addValue(){
        setArr([...Arr,Num])
        setNum((x)=>x=x+1)
    }
    return(
        <>
        <h1>This is Task2 Component</h1>
        {
            Arr.map((value)=>
                <h1>{value}</h1>
            )
        }
        <button onClick={addValue}>Add Item</button>
        </>
    )
}
export default Task2