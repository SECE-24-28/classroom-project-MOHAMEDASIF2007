// import { useState } from "react"; 
// const Task1=()=>{
//     const [Name,setName]=useState("")
//     const [Gender,setGender]=useState("")
//     const [Contact,setContact]=useState(0)
//     return(
//         <>
//         <h1>Task1 Component</h1>
//         <h1>Name: {Name}</h1>
//         <h1>Gender: {Gender}</h1>
//         <h1>Contact: {Contact}</h1>
//         </>
//     )
// }
// export default Task1

import { useState } from "react"; 
const Task1=()=>{
    const [Student,setStudent]=useState({
        Name:"Rahul",
        Gender:"Male",
        Contact:1234567890
    })
    function updateName(){
        setStudent((prevState)=>{
            console.log("Previous State:",prevState)
            return {...prevState,Name:"Rohit",Contact:9876543210}
        })
    }
    return(
        <>
        <h1>Task1 Component</h1>
        <h1>Name: {Student.Name}</h1>
        <h1>Gender: {Student.Gender}</h1>
        <h1>Contact: {Student.Contact}</h1>
        <button onClick={updateName}>Update Name</button>
        </>
    )
}
export default Task1